package com.smhrd.order.model;

public class OrderDAO {

}
