package com.smhrd.order.model;

public class OrderDTO {

}
