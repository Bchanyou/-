package com.smhrd.ingredients.model;

public class IngredientsDAO {

}
