package com.smhrd.board.model;

import java.sql.Timestamp;
import java.time.LocalDateTime;

public class BoardDTO {

    

}
