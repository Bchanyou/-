package com.smhrd.recipe.model;

public class RecipeDTO {

}
