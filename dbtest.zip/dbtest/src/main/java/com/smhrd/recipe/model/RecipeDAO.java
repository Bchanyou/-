package com.smhrd.recipe.model;

public class RecipeDAO {

}
